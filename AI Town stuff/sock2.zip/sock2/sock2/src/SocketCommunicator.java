
/**
 *
 * @author s
 */
public interface SocketCommunicator
{
	public void inputReceived(String text);
	public void notify(String msg);
	
}
