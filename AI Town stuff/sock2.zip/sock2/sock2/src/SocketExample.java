
/**
 *
 * @author s
 */
public class SocketExample
{

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args)
	{
		ExampleUIFrame frame = new ExampleUIFrame();
		frame.setVisible(true);
	}
}
